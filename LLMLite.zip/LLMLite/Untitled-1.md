
## App Flow Diagram

```mermaid
flowchart TD
	U[User] --> F[Frontend UI\nHTML / JS Dashboard]

	subgraph Frontend
		F --> S1[Submit Claim]
		F --> S2[View Pipeline, Metrics, Explainability]
		F --> S3[Clear Old Request]
		F --> S4[Clear Recent Requests]
	end

	S1 --> API1[POST /api/claim]
	F --> API2[GET /api/stats]
	F --> API3[GET /api/teams]
	F --> API4[GET /api/models]
	F --> API5[GET /api/recent]
	S4 --> API6[DELETE /api/recent]

	subgraph FastAPI Backend
		API1 --> G[LLMGateway.process_claim]
		API2 --> L1[UsageLogger.summary_stats]
		API3 --> L2[UsageLogger.team_budgets]
		API4 --> L3[UsageLogger.model_stats]
		API5 --> L4[UsageLogger.recent_requests]
		API6 --> L5[UsageLogger.clear_requests]
	end

	subgraph Gateway Pipeline
		G --> PII[PII Masking\nemail / phone / SSN / PAN / Aadhaar]
		PII --> CLS[Task Classification\nsimple vs complex\n+ token estimate]
		CLS --> CACHE{Response\nCache Hit?}
		CACHE -- Yes --> CACHED[Return cached summary\n$0 cost / 0 tokens]
		CACHE -- No --> ROUTE[Model Routing]
		ROUTE --> DECIDE{Task Type}
		DECIDE -- Simple --> M1[Primary: Azure OpenAI\nazure/gpt-4o-mini]
		DECIDE -- Complex --> M2[Primary: Azure OpenAI\nazure/gpt-4o]
		M1 --> FB{Primary available?}
		M2 --> FB
		FB -- Yes --> RESP[LLM Response]
		FB -- No --> FALLBACK[Fallback Chain\nAzure secondary -> Groq Llama]
		FALLBACK --> RESP
		RESP --> COST[Cost + Token Calculation]
		COST --> SAVE[Save to Cache]
		SAVE --> EXPLAIN[Build Explainability\nwhy model was selected]
		EXPLAIN --> LOG[Log request metadata]
	end

	subgraph Storage
		RC[(SQLite response_cache)]
		RL[(SQLite request_logs)]
	end

	CACHE -. lookup .-> RC
	SAVE --> RC
	LOG --> RL
	L1 --> RL
	L2 --> RL
	L3 --> RL
	L4 --> RL
	L5 --> RL

	CACHED --> OUT[JSON Response]
	LOG --> OUT
	OUT --> F

	F --> DASH[Live Dashboard\nrequests / cost / cache / models / teams]
```

## Request Processing Sequence

```mermaid
sequenceDiagram
	participant User
	participant Frontend
	participant API as FastAPI
	participant Gateway as LLMGateway
	participant Cache as SQLite Cache
	participant Model as Azure OpenAI / Groq
	participant Logs as SQLite Logs

	User->>Frontend: Submit claim text
	Frontend->>API: POST /api/claim
	API->>Gateway: process_claim()
	Gateway->>Gateway: Mask PII
	Gateway->>Gateway: Classify task + estimate tokens
	Gateway->>Cache: Lookup masked claim

	alt Cache hit
		Cache-->>Gateway: Cached summary
		Gateway->>Logs: Log cache hit
		Gateway-->>API: Response + metrics
	else Cache miss
		Gateway->>Gateway: Route to selected model
		Gateway->>Model: Send masked claim
		alt Primary model fails
			Gateway->>Model: Retry fallback model
		end
		Model-->>Gateway: Summary + token usage
		Gateway->>Cache: Save response
		Gateway->>Gateway: Build explainability
		Gateway->>Logs: Log tokens, cost, latency, provider
		Gateway-->>API: Response + explainability
	end

	API-->>Frontend: JSON result
	Frontend-->>User: Summary + pipeline + dashboard updates
```